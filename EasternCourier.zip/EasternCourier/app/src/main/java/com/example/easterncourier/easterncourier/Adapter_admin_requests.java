package com.example.easterncourier.easterncourier;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class Adapter_admin_requests extends RecyclerView.Adapter<Adapter_admin_requests.myViewHolder> {
    Context mContextAdminRequests;
    List<admin_request_item> mDataAdminRequests;

    public Adapter_admin_requests(Context mContextAdminRequests, List<admin_request_item> mDataAdminRequests) {
        this.mContextAdminRequests = mContextAdminRequests;
        this.mDataAdminRequests = mDataAdminRequests;
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(mContextAdminRequests);
        View v=inflater.inflate(R.layout.activity_admin_requests,parent,false);
        return new myViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
        holder.clientImage.setImageResource(mDataAdminRequests.get(position).getClientImage());
        holder.clientName.setText(mDataAdminRequests.get(position).getClientName());
        holder.clientTimeRequest.setText(mDataAdminRequests.get(position).getClientTimeRequest());
    }

    @Override
    public int getItemCount() {
        return mDataAdminRequests.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder{
        ImageView clientImage;
        TextView clientName,clientTimeRequest;
        public myViewHolder(View itemView) {
            super(itemView);
            clientImage=itemView.findViewById(R.id.courierPicture);
            clientName=itemView.findViewById(R.id.courierName);
            clientTimeRequest=itemView.findViewById(R.id.numOfDesignatedClients);
        }
    }
}
