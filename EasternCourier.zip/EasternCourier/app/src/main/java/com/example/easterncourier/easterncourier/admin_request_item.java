package com.example.easterncourier.easterncourier;

public class admin_request_item {
    int clientImage;
    String clientName,clientTimeRequest;

    public admin_request_item(int clientImage, String clientName, String clientTimeRequest) {
        this.clientImage = clientImage;
        this.clientName = clientName;
        this.clientTimeRequest = clientTimeRequest;
    }

    public int getClientImage() {
        return clientImage;
    }

    public String getClientName() {
        return clientName;
    }

    public String getClientTimeRequest() {
        return clientTimeRequest;
    }

    public void setClientImage(int clientImage) {
        this.clientImage = clientImage;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public void setClientTimeRequest(String clientTimeRequest) {
        this.clientTimeRequest = clientTimeRequest;
    }
}
