package com.example.easterncourier.easterncourier;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class admin_requests extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_requests);

        RecyclerView recyclerView=findViewById(R.id.rv_listRequests);
        List<admin_request_item> mListAdminRequests=new ArrayList<>();

        //mListAdminRequests.add(new admin_request_item("You've sent a package for Christian Bautista,","Just now","5:00a.m"));

        Adapter_admin_requests adapter_admin_requests=new Adapter_admin_requests(this,mListAdminRequests);
        recyclerView.setAdapter(adapter_admin_requests);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}
